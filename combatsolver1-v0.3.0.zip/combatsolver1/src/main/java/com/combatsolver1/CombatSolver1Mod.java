package com.combatsolver1;

import basemod.BaseMod;
import basemod.interfaces.OnPlayerTurnStartSubscriber;
import basemod.interfaces.OnStartBattleSubscriber;
import basemod.interfaces.PostBattleSubscriber;
import basemod.interfaces.PostDrawSubscriber;
import basemod.interfaces.PostInitializeSubscriber;
import basemod.interfaces.PostRenderSubscriber;
import basemod.interfaces.PostUpdateSubscriber;
import basemod.interfaces.OnCardUseSubscriber;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.evacipated.cardcrawl.modthespire.lib.SpireInitializer;
import com.megacrit.cardcrawl.cards.AbstractCard;
import com.megacrit.cardcrawl.core.AbstractCreature;
import com.megacrit.cardcrawl.rooms.AbstractRoom;

import com.combatsolver1.runtime.CombatController;

/**
 * Mod 入口。ModTheSpire 通过 @SpireInitializer 注解发现本类并调用 initialize()。
 */
@SpireInitializer
public class CombatSolver1Mod implements
        PostInitializeSubscriber,
        OnStartBattleSubscriber,
        PostBattleSubscriber,
        OnPlayerTurnStartSubscriber,
        PostDrawSubscriber,
        PostUpdateSubscriber,
        OnCardUseSubscriber,
        PostRenderSubscriber {

    public static final String MOD_ID = "combatsolver1";
    public static final String MOD_NAME = "Combat Solver 1";

    @SuppressWarnings("unused")
    public static void initialize() {
        CombatSolver1Mod mod = new CombatSolver1Mod();
        BaseMod.subscribe(mod);
        CombatLog.info("initialized");
    }

    @Override
    public void receivePostInitialize() {
        // 外部引擎（sts_lightspeed）是可选的：路径从系统属性 / 环境变量 / 设置文件读取，
        // 不再写死开发机路径；无论启用还是回退都在日志里说明原因，测试结果才能追溯来源。
        configureEngineBridge();
        CombatLog.info("post-initialize");
    }

    private static void configureEngineBridge() {
        String engine = firstNonEmpty(System.getProperty("combatsolver1.engine"),
                System.getenv("COMBATSOLVER1_ENGINE"), settingsValue("engine.path"));
        String mingw = firstNonEmpty(System.getProperty("combatsolver1.mingw"),
                System.getenv("COMBATSOLVER1_MINGW"), settingsValue("engine.mingw"));
        if (engine.isEmpty()) {
            CombatLog.info("solver source: local java search"
                    + "（未配置外部引擎；设置文件 ~/.combatsolver1/settings.properties 里写 engine.path=... 可启用）");
            return;
        }
        if (!new java.io.File(engine).isFile()) {
            CombatLog.info("solver source: local java search（配置的外部引擎不存在：" + engine + "）");
            return;
        }
        com.combatsolver1.runtime.EngineBridge.configure(engine, mingw);
        CombatLog.info("solver source: sts_lightspeed (" + engine + ")"
                + (mingw.isEmpty() ? "" : "，MinGW: " + mingw));
    }

    private static String firstNonEmpty(String... values) {
        for (String value : values) {
            if (value != null && !value.trim().isEmpty()) {
                return value.trim();
            }
        }
        return "";
    }

    /** 从 ~/.combatsolver1/settings.properties 读一个键（没有返回空串）。 */
    private static String settingsValue(String key) {
        java.io.File file = new java.io.File(
                new java.io.File(System.getProperty("user.home", "."), ".combatsolver1"),
                "settings.properties");
        if (!file.isFile()) {
            return "";
        }
        java.util.Properties properties = new java.util.Properties();
        try (java.io.InputStream in = new java.io.FileInputStream(file)) {
            properties.load(in);
            return properties.getProperty(key, "");
        } catch (Throwable t) {
            return "";
        }
    }

    @Override
    public void receiveOnBattleStart(AbstractRoom battleRoom) {
        CombatController.instance().onBattleStart(battleRoom);
    }

    @Override
    public void receivePostBattle(AbstractRoom battleRoom) {
        com.combatsolver1.runtime.CombatRecorder.onBattleEnd();
        CombatController.instance().onBattleEnd();
    }

    @Override
    public void receiveCardUsed(AbstractCard card) {
        com.combatsolver1.runtime.CombatRecorder.onCardUsed(card.cardID, card.costForTurn,
                card.damage, card.block, CombatController.instance().recordingTarget());
        CombatController.instance().onCardUsed(card);
    }

    @Override
    public void receiveOnPlayerTurnStart() {
        CombatController.instance().onPlayerTurnStart();
    }

    @Override
    public void receivePostDraw(AbstractCard drawnCard) {
        CombatController.instance().onCardDrawn(drawnCard);
    }

    @Override
    public void receivePostUpdate() {
        CombatController.instance().update();
    }

    @Override
    public void receivePostRender(SpriteBatch sb) {
        CombatController.instance().render(sb);
    }
}
